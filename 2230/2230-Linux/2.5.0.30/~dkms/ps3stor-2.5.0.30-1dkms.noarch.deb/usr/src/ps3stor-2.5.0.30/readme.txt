Compile dependencies pkgs:kernel-devel kernel-headers

1. compiling
	compile.sh: a script compiling the driver source.

2、cleaning
	clean.sh : a script for cleaning the driver source tree.
