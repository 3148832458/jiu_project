#!/bin/bash
#
# clean.sh: a script clean the driver.
#

make clean

exit 0
